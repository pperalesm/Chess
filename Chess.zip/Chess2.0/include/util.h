#ifndef INCLUDE_UTIL_H_
#define INCLUDE_UTIL_H_

#define BLACK 0
#define WHITE 1
#define BISHOP 0
#define KING 1
#define KNIGHT 2
#define PAWN 3
#define QUEEN 4
#define ROOK 5

#endif /* INCLUDE_UTIL_H_ */
